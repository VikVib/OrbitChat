# Netlify-ready Discord-like Chat (Firebase backend)

This version is a purely static site (HTML/CSS/JS) that uses **Firebase Realtime Database** for realtime messaging and presence.
Because Netlify hosts static sites only, we switched the server-side Socket.IO Node server to Firebase so Netlify can host the site directly.

## Steps to deploy on Netlify
1. Create a Firebase project at https://console.firebase.google.com
2. In Firebase, add a **Web app** and copy the firebase config object (it looks like `{ apiKey: '...', authDomain: '...', databaseURL: 'https://...rtdb.firebaseio.com', ... }`).
3. Open `public/app.js` and paste your firebase config into the `firebaseConfig` variable near the top.
4. In Firebase Console > Realtime Database, create a database and set rules to allow read/write while testing (see SECURITY note below).
5. From the project root, deploy the `public/` folder to Netlify (drag-and-drop or connect a Git repo). Netlify will serve the static files.

## Security & next steps
- **Important:** This demo uses open Realtime Database rules for simplicity during testing. Do **not** use open rules in production. Learn about Firebase Authentication and secure rules to restrict writes/reads.
- If you want authentication (Google, email/password), I can add Firebase Auth integration so presence and messages are tied to users.

## Local testing
You can also test locally by opening `public/index.html` in your browser after adding your Firebase config.

Enjoy — tell me if you want me to: add Firebase Auth, message history UI, message delete, or convert to Firestore instead of Realtime DB.
