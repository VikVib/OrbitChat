/*
  Firebase-powered static chat client.
  IMPORTANT: Replace the firebaseConfig object below with your Firebase project's config.
  How to get it:
  1. Go to https://console.firebase.google.com/ -> Create a project (or use existing).
  2. Add a Web app and copy the config shown (apiKey, authDomain, databaseURL, projectId, storageBucket, messagingSenderId, appId).
  3. Paste the config below in the firebaseConfig variable.
*/

// Paste your config here:
const firebaseConfig = {
  /* Example:
  apiKey: "YOUR_API_KEY",
  authDomain: "your-app.firebaseapp.com",
  databaseURL: "https://your-app-default-rtdb.firebaseio.com",
  projectId: "your-app",
  storageBucket: "your-app.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:123:web:abcd"
  */
};

if(!firebaseConfig || !firebaseConfig.apiKey){
  // show a helpful message in the page
  document.write("<h2 style='color:#fff;background:#111;padding:20px'>Firebase config missing — open public/app.js and paste your Firebase config object (see README)</h2>");
  throw new Error('Firebase config missing');
}

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// UI
const serverInput = document.getElementById('server-id-input');
const joinBtn = document.getElementById('join-server');
const createBtn = document.getElementById('create-server');
const nameInput = document.getElementById('name-input');
const setNameBtn = document.getElementById('set-name');
const messagesEl = document.getElementById('messages');
const msgForm = document.getElementById('msg-form');
const msgInput = document.getElementById('msg-input');
const currentServerEl = document.getElementById('current-server');
const userListEl = document.getElementById('user-list');
const savedServersEl = document.getElementById('saved-servers');
const addServerBtn = document.getElementById('add-server');

let currentServer = null;
let username = localStorage.getItem('cc_username') || ('User' + Math.floor(Math.random()*1000));
nameInput.value = username;

function addSavedServer(sid){
  const b = document.createElement('div'); b.className='sv'; b.textContent = sid[0]||'#';
  b.title = sid;
  b.onclick = ()=>{ joinServer(sid); };
  savedServersEl.appendChild(b);
}
const saved = JSON.parse(localStorage.getItem('cc_saved_servers')||'[]');
saved.forEach(addSavedServer);

addServerBtn.onclick = ()=>{
  const sid = prompt('New server id (short, no spaces):','my-server');
  if(!sid) return;
  const arr = JSON.parse(localStorage.getItem('cc_saved_servers')||'[]');
  if(!arr.includes(sid)){ arr.push(sid); localStorage.setItem('cc_saved_servers', JSON.stringify(arr)); addSavedServer(sid); }
};

function renderMessage(data, system=false){
  const d = document.createElement('div'); d.className='message';
  const meta = document.createElement('div'); meta.className='meta';
  meta.textContent = system ? `[system] ${new Date(data.ts).toLocaleTimeString()} ` : `${data.username} • ${new Date(data.ts).toLocaleTimeString()}`;
  const text = document.createElement('div'); text.textContent = data.text;
  d.appendChild(meta); d.appendChild(text);
  messagesEl.appendChild(d);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

joinBtn.onclick = ()=>{ joinServer(serverInput.value || 'general'); };
createBtn.onclick = ()=>{ const sid = serverInput.value || 'general'; createServer(sid); joinServer(sid); };

function joinServer(sid){
  if(!sid) return alert('Enter server id');
  if(currentServer) leaveServer(currentServer);
  currentServer = sid;
  currentServerEl.textContent = `Server: ${sid}`;
  // presence: add user to /presence/{server}/{uid}
  const uid = username + '_' + Math.floor(Math.random()*100000);
  localStorage.setItem('cc_uid', uid);
  const presRef = db.ref('presence/' + sid + '/' + uid);
  presRef.set({username, ts: Date.now()});
  presRef.onDisconnect().remove();

  // listen for presence updates
  db.ref('presence/' + sid).on('value', snap => {
    const v = snap.val() || {};
    const names = Object.values(v).map(x=>x.username);
    userListEl.innerHTML = '<strong>Users</strong><br/>' + names.map(x=>`<div>${x}</div>`).join('');
  });

  // listen for messages
  db.ref('messages/' + sid).limitToLast(200).on('child_added', snap => {
    const m = snap.val();
    renderMessage(m, m.system);
  });
}

function leaveServer(sid){
  const uid = localStorage.getItem('cc_uid');
  if(uid) db.ref('presence/' + sid + '/' + uid).remove();
  db.ref('presence/' + sid).off();
  db.ref('messages/' + sid).off();
  messagesEl.innerHTML = '';
}

function createServer(sid){
  // simply ensure there's a node; messages and presence create themselves when used
  db.ref('servers/' + sid).set({created: Date.now()});
  alert('Server created: ' + sid);
}

setNameBtn.onclick = ()=>{ username = nameInput.value || 'Anon'; localStorage.setItem('cc_username', username); alert('Name set'); };

msgForm.addEventListener('submit', e=>{
  e.preventDefault();
  const txt = msgInput.value.trim();
  if(!txt || !currentServer) return;
  const m = {username, text: txt, ts: Date.now(), system: false};
  db.ref('messages/' + currentServer).push(m);
  msgInput.value = '';
});

// auto-join general on load
if(!currentServer){ serverInput.value = 'general'; /* don't auto-join until user clicks to avoid accidental presence */ }
